<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <title>NFBOX Apps</title>
</head>
<body>
<p>Dear {{ $user->first_name }},</p>
<p>{{ $body }}</p>
</body>
</html>